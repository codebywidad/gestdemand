export default function CTA(){
    return <>
    <section class="section-appel-action" id="contact">
            <h2>Projet académique - M204 Développement Front-end</h2>
            <p>Filière Développement Digital - Option Web Full Stack</p>
            <div class="groupe-boutons">
                <a href="#" class="bouton bouton-principal">Voir le code source</a>
                <a href="#" class="bouton bouton-secondaire">Télécharger le rapport</a>
            </div>
        </section>
    </>
    ;


}