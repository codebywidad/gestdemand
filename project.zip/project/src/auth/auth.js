import { Outlet } from "react-router";

export default function Auth(){

    return<>
        <Outlet />
    </>

}